package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public PieChart piechart;
    public String Host = "http://tcc3yetecgrupo1t1.hospedagemdesites.ws";
    public String url;



    int i=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        piechart=(PieChart) findViewById(R.id.pie_chart);
        List<PieEntry> list= new ArrayList<PieEntry>();
        try {
            url = Host + "listarp.php";
            Ion.with(getBaseContext())
                    .load(url)
                    .asJsonArray()
                    .setCallback(new FutureCallback<JsonArray>() {
                        @Override
                        public void onCompleted(Exception e, JsonArray result) {
                            list.clear();
                            for (i = 0; i < result.size(); i++) {
                                JsonObject retx = result.get(i).getAsJsonObject();
                                list.add(new PieEntry(Float.parseFloat(retx.get("quant").getAsString().toString()), retx.get("nome").getAsString().toString()));
                            }
                            PieDataSet pieDataSet = new PieDataSet(list, "List");
                            pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255);
                            pieDataSet.setValueTextColor(Color.BLACK);
                            pieDataSet.setValueTextSize(15f);
                            PieData pieData = new PieData(pieDataSet);
                            piechart.setData(pieData);
                            piechart.setCenterText("Lista prod");
                            piechart.animateY(2000);
                        }
                    });
        }
        catch (Exception e )
        {
            Toast.makeText(this, "Infelizmente ocorreu um erro.", Toast.LENGTH_LONG).show();
        }



    }



}
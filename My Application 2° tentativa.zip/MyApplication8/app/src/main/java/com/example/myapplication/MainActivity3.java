package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {
    public PieChart piechart;
    public String Host = "http://tcc3yetecgrupo1t1.hospedagemdesites.ws";
    public String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        piechart = (PieChart) findViewById(R.id.pie_chart);
        List<PieEntry> list = new ArrayList<>();

        try {
            // Ajustado caminho para /Dados/ (com D maiúsculo)
            url = Host + "/Dados/listarp.php";

            Ion.with(getBaseContext())
                    .load(url)
                    .asJsonArray()
                    .setCallback(new FutureCallback<JsonArray>() {
                        @Override
                        public void onCompleted(Exception e, JsonArray result) {
                            if (e != null || result == null) {
                                String erroMsg = (e != null) ? e.getMessage() : "Resposta nula do servidor";
                                Toast.makeText(getBaseContext(), "Erro: " + erroMsg, Toast.LENGTH_LONG).show();
                                return;
                            }

                            list.clear();
                            for (int i = 0; i < result.size(); i++) {
                                JsonObject retx = result.get(i).getAsJsonObject();

                                if (retx.has("quant") && retx.has("nome")) {
                                    try {
                                        float quant = Float.parseFloat(retx.get("quant").getAsString().replace(",", "."));
                                        String nome = retx.get("nome").getAsString();
                                        list.add(new PieEntry(quant, nome));
                                    } catch (NumberFormatException ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            }

                            if (!list.isEmpty()) {
                                PieDataSet pieDataSet = new PieDataSet(list, "Lista Produtos");
                                pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
                                pieDataSet.setValueTextColor(Color.BLACK);
                                pieDataSet.setValueTextSize(15f);

                                PieData pieData = new PieData(pieDataSet);
                                piechart.setData(pieData);
                                piechart.setCenterText("Produtos");
                                piechart.animateY(2000);

                                piechart.invalidate(); // Força a renderização na tela
                            } else {
                                Toast.makeText(getBaseContext(), "Nenhum dado retornado para o gráfico de pizza.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Erro interno no app: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
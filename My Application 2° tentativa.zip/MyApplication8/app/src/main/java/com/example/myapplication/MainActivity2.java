package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    public BarChart barchart;
    public String Host = "http://tcc3yetecgrupo1t1.hospedagemdesites.ws";
    public String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        barchart = (BarChart) findViewById(R.id.bar_chart);
        List<BarEntry> list = new ArrayList<>();

        try {
            // Ajustado caminho para /Dados/ (com D maiúsculo)
            url = Host + "/Dados/listarp.php";

            Ion.with(getBaseContext())
                    .load(url)
                    .asJsonArray()
                    .setCallback(new FutureCallback<JsonArray>() {
                        @Override
                        public void onCompleted(Exception e, JsonArray result) {
                            if (e != null || result == null) {
                                String erroMsg = (e != null) ? e.getMessage() : "Resposta nula do servidor";
                                Toast.makeText(getBaseContext(), "Erro: " + erroMsg, Toast.LENGTH_LONG).show();
                                return;
                            }

                            list.clear();

                            // Preenchimento dos dados no gráfico de barras
                            for (int i = 0; i < result.size(); i++) {
                                JsonObject obj = result.get(i).getAsJsonObject();
                                if (obj.has("quant") && !obj.get("quant").isJsonNull()) {
                                    try {
                                        float valor = Float.parseFloat(obj.get("quant").getAsString().replace(",", "."));
                                        // BarEntry recebe (índice_X, valor_Y)
                                        list.add(new BarEntry(i, valor));
                                    } catch (NumberFormatException ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            }

                            if (!list.isEmpty()) {
                                BarDataSet barDataSet = new BarDataSet(list, "Produtos");
                                barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
                                barDataSet.setValueTextColor(Color.BLACK);
                                barDataSet.setValueTextSize(15f);

                                BarData barData = new BarData(barDataSet);
                                barchart.setData(barData);
                                barchart.animateY(2000);
                                barchart.invalidate(); // Força a renderização na tela
                            } else {
                                Toast.makeText(getBaseContext(), "Nenhum dado retornado para o gráfico de barras.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Erro interno no app: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
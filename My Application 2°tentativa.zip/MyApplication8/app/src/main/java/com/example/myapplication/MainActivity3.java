package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {
    public PieChart piechart;
    public String Host = "http://tcc3yetecgrupo1t1.hospedagemdesites.ws";
    public String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        piechart = (PieChart) findViewById(R.id.pie_chart);
        List<PieEntry> list = new ArrayList<>();

        try {
            // Correção 1: Adicionada a barra / antes do arquivo PHP
            url = Host + "/dados/listarp.php";

            Ion.with(getBaseContext())
                    .load(url)
                    .asJsonArray()
                    .setCallback(new FutureCallback<JsonArray>() {
                        @Override
                        public void onCompleted(Exception e, JsonArray result) {
                            // Correção 2: Validação de erros e respostas nulas
                            if (e != null || result == null) {
                                Toast.makeText(getBaseContext(), "Erro ao carregar dados do servidor.", Toast.LENGTH_LONG).show();
                                return;
                            }

                            list.clear();
                            for (int i = 0; i < result.size(); i++) {
                                JsonObject retx = result.get(i).getAsJsonObject();

                                if (retx.has("quant") && retx.has("nome")) {
                                    float quant = Float.parseFloat(retx.get("quant").getAsString());
                                    String nome = retx.get("nome").getAsString();
                                    list.add(new PieEntry(quant, nome));
                                }
                            }

                            PieDataSet pieDataSet = new PieDataSet(list, "Lista");
                            pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
                            pieDataSet.setValueTextColor(Color.BLACK);
                            pieDataSet.setValueTextSize(15f);

                            PieData pieData = new PieData(pieDataSet);
                            piechart.setData(pieData);
                            piechart.setCenterText("Lista prod");
                            piechart.animateY(2000);

                            // Correção 3: Atualiza o layout do gráfico na tela
                            piechart.invalidate();
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Infelizmente ocorreu um erro.", Toast.LENGTH_LONG).show();
        }
    }
}
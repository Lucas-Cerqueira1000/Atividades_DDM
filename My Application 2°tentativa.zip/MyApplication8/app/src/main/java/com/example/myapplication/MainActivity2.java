package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    public BarChart barchart;
    public String Host = "http://tcc3yetecgrupo1t1.hospedagemdesites.ws";
    public String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        barchart = (BarChart) findViewById(R.id.bar_chart);

        // Declaração explícita do tipo BarEntry na lista
        List<BarEntry> list = new ArrayList<BarEntry>();

        try {
            url = Host + "/dados/listarp.php";

            Ion.with(getBaseContext())
                    .load(url)
                    .asJsonArray()
                    .setCallback(new FutureCallback<JsonArray>() {
                        @Override
                        public void onCompleted(Exception e, JsonArray result) {
                            // Trata erros de conexão ou resposta nula
                            if (e != null || result == null) {
                                Toast.makeText(MainActivity2.this, "Infelizmente ocorreu um erro.", Toast.LENGTH_LONG).show();
                                return;
                            }

                            list.clear();

                            // Percorre o JsonArray para preencher a lista
                            for (int i = 0; i < result.size(); i++) {
                                // Exemplo de como extrair dados do JSON e adicionar ao gráfico:
                                // JsonObject obj = result.get(i).getAsJsonObject();
                                // float valor = obj.get("campo_valor").getAsFloat();
                                // list.add(new BarEntry(i, valor));
                            }

                            // Configuração do DataSet e do Chart
                            BarDataSet barDataSet = new BarDataSet(list, "List");
                            barDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255);
                            barDataSet.setValueTextColor(Color.BLACK);
                            barDataSet.setValueTextSize(15f);

                            BarData barData = new BarData(barDataSet);
                            barchart.setData(barData);
                            barchart.animateY(2000);
                            barchart.invalidate(); // Recarrega o gráfico no ecrã
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Infelizmente ocorreu um erro.", Toast.LENGTH_LONG).show();
        }
    }
}